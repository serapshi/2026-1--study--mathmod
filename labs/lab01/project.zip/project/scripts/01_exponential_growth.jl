# # Экспоненциальный рост
# **Цель:** Исследовать решение уравнения $du/dt = \alpha u$.
#
# ## Инициализация проекта и загрузка пакетов
using DrWatson
@quickactivate "project"
using DifferentialEquations
using Plots
using DataFrames
using JLD2

script_name = "01_exponential_growth"  # фиксированное имя: PROGRAM_FILE пуст в Jupyter/Quarto
mkpath(plotsdir(script_name))
mkpath(datadir(script_name))

# ## Определение модели
# Уравнение экспоненциального роста:
#
# $$\frac{du}{dt} = \alpha u, \quad u(0) = u_0$$
function exponential_growth!(du, u, p, t)
    α = p
    du[1] = α * u[1]
end

# ## Первый запуск с параметрами по умолчанию
# Зададим начальные параметры:
u0 = [1.0]          # начальная популяция
α = 0.3            # скорость роста
tspan = (0.0, 10.0) # временной интервал

prob = ODEProblem(exponential_growth!, u0, tspan, α)
sol = solve(prob, Tsit5(), saveat=0.1)

# ## Визуализация результатов
# Построим график решения:
plot(sol, label="u(t)", xlabel="Время t", ylabel="Популяция u",
     title="Экспоненциальный рост (α = $α)", lw=2, legend=:topleft)

# Сохраним график в папку plots
savefig(plotsdir(script_name, "exponential_growth_α=$α.png"))

# ## Анализ результатов
# Создадим таблицу с данными:
df = DataFrame(t=sol.t, u=first.(sol.u))
println("Первые 5 строк результатов:")
println(first(df, 5))

# Вычислим удвоение популяции:
u_final = last(sol.u)[1]
doubling_time = log(2) / α
println("\nАналитическое время удвоения: ", round(doubling_time; digits=2))

# ## Сохранение всех результатов
@save datadir(script_name, "all_results.jld2") df